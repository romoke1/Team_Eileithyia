<div class="footer" style="margin-top: 10%;">
      <p><i class="fa fa-heart"></i>&nbsp;Copyright Thyla E-Learning. All Rights Reserved 2019.</p>
  </div>

</div>

</body>
</html>